const { app, BrowserWindow } = require("electron");

function createWindow() {
  const win = new BrowserWindow({
    width: 1100,
    height: 800,
    webPreferences: {
      contextIsolation: true
    }
  });

  win.loadFile("tracker.html");
}

app.whenReady().then(createWindow);