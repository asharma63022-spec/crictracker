# Monk Mode Tracker

This folder is a ready-to-host installable web app version of the tracker.

## Files

- index.html
- style.css
- app.js
- manifest.json
- service-worker.js
- icons/

## Use Locally

Open index.html in a browser. For install/offline testing, serve the folder with any static server.

## Publish

### GitHub Pages

1. Create a GitHub repository.
2. Upload everything inside this folder.
3. Go to Settings > Pages.
4. Choose the main branch and root folder.
5. Share the GitHub Pages link.

### Netlify

1. Go to Netlify.
2. Drag this folder into the deploy screen.
3. Share the generated site link.

### Vercel

1. Create a new Vercel project.
2. Upload or connect this folder/repository.
3. Deploy and share the link.

## Backup

Use Export Data to download a JSON backup. Use Import Data to restore it later.
